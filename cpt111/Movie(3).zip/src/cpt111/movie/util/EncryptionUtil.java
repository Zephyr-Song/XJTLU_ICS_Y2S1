package cpt111.movie.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets; // Import UTF-8 encoding class

public class EncryptionUtil {

    public static String encryptPassword(String plainPassword) throws NoSuchAlgorithmException {
        if (plainPassword == null || plainPassword.trim().isEmpty()) {
            throw new IllegalArgumentException("Plaintext password cannot be empty");
        }

        // 1. Get MD5 encryption instance
        MessageDigest md = MessageDigest.getInstance("MD5");
        // 2. Key modification: Force use UTF-8 encoding to convert to byte array to avoid system encoding differences
        byte[] hashBytes = md.digest(plainPassword.trim().getBytes(StandardCharsets.UTF_8));
        // 3. Convert byte array to 32-bit hexadecimal string
        StringBuilder sb = new StringBuilder();
        for (byte b : hashBytes) {
            sb.append(String.format("%02x", b)); // %02x means pad with zero to 2-digit hexadecimal number
        }
        return sb.toString();
    }
}