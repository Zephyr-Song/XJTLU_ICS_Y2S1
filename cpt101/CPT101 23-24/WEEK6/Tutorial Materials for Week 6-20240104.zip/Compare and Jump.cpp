// Practical 3 for Fall 2017 Semester.cpp : Defines the entry point for the console application.
//

#include <iostream>

int main()
{
	char msgSelectPositiveInt[]	= "Select total number of positive integers (between 2-5): ";
	char msgEnterPositiveInt[]	= "Enter positive integer %d: ";
	char msgProgEnds[]			= "\nProgram terminates and has looped %d times.\n\n";
	char msgListInt[]			= "Your integers from lowest to highest are ";
	char msgComma[]				= " , ";
	char msgTotalAmt[]			= "\n\nThe total amount is %d \n\n";
	
	char format[]				= "%d";  // format string for the scanf function

	int totalNumInt;
	int intList[5];

	int cntNumInt = 0;
	int positiveInt;
	int totalAmt = 0;
	
	_asm{

	readTotalPositiveInt:
		lea		eax, msgSelectPositiveInt
		push	eax								
		call	printf						; print message requesting user to enter total number of positive integers
		add		esp, 4

		lea		eax, totalNumInt   
		push	eax  
		lea		eax, format  
		push	eax   
		call	scanf_s						; read user input of total number of positive integers   
		add		esp, 8

		mov		eax, totalNumInt
		cmp		eax, 5
		jg		readTotalPositiveInt		; loop back if input is more than 5
		cmp		eax, 2
		jl		readTotalPositiveInt		; loop back if input is less than 2
				
		lea		esi, intList				; load memory address of the first item in integer array into esi register

	readIntList:
		inc		cntNumInt
		mov		eax, cntNumInt
		cmp		totalNumInt, eax			; compare total number of positive integers with current count
		js		printNumLoop				; if total number of positive integers is less than current count, jump to print number of loops message

		push	eax
		lea		eax, msgEnterPositiveInt
		push	eax              
		call	printf						; print message for user to enter a positive integer one at a time
		add		esp, 8

		lea		eax, positiveInt
		push	eax
		lea		eax, format   
		push	eax
		call	scanf_s						; read user input of a positive integer
		add		esp, 8

		cmp		positiveInt, 0				; compare user input with zero
		js		printNumLoop				; if user enters a negative integer, jump to print number of loops message
		
		mov		eax, positiveInt
		mov		[esi], eax					; otherwise move user input of a positive integer into memory address pointed by esi register
		add		esi, 4						; incrememt memory address by 4-byte as pointed by esi register

		jmp		readIntList					; loop back to process next positive integer
		
	printNumLoop:
		dec		cntNumInt
		mov		ebx, cntNumInt
		push	ebx
		lea		ebx, msgProgEnds
		push	ebx
		call	printf						; print program ends and number of loops message	
		add		esp, 8

		mov		ecx, cntNumInt				; save number of positive integers into ecx register
		cmp		ecx, 0						; check if user input zero number
		je		finish				; if equal, jump to print total amount
		cmp		ecx, 1						; check if user input only 1 number
		je		printSortedIntMsg			; if equal, jump to print sorted integers
		dec		ecx
	
	L1:
		push	ecx							; save outer loop count
		lea		esi, intList				; load memory address of the first item in integer array into esi register			
	
	L2:
		mov		eax, [esi]					; load the content of memory address pointed by esi register
		cmp		[esi+4], eax				; compare the contents between adjacent memory addresses
		jge		L3							; if [esi+4] >= [esi], skip to outer loop
		xchg	eax, [esi+4]				; otherwise exchange the contents between adjacent memory addresses					
		mov		[esi], eax					; continue with the exchange via eax register
	L3 :
		add		esi, 4						; move pointer to next memory address of the integer array
		loop	L2							; continue with inner loop
		pop		ecx							; retrieve outer loop count
		loop	L1							; else repeat outer loop

	printSortedIntMsg:
		lea		eax, msgListInt
		push	eax							; printing messsage listing sorted integers
		call	printf
		add		esp, 4
		
		mov		ebx, cntNumInt
		dec		ebx
		lea		esi, intList				; load memory address of the first item in integer array into esi register

	printSortedInt:
		cmp		ebx, 0
		js		printTotalAmt
		
		mov		eax, [esi]
		push	eax
		lea		eax, format
		push	eax
		call	printf						; print positive integers in reverse
		add		esp, 8

		cmp		ebx, 1
		js		skipLastComma				; skip from printing comma if it is the last integer

		lea		eax, msgComma
		push	eax              
		call	printf						; print comma to separate integer list
		add		esp, 4
	
	skipLastComma:
		add		esi, 4
		dec		ebx
		jmp		printSortedInt

	printTotalAmt:
		lea		edi, intList				; load memory address of the first item in integer array into edi register
		mov		ecx, cntNumInt				; save number of positive integers into ecx register
		mov		eax, totalAmt				; set total amount to zero
	
	addPositiveInt:
		add		eax, [edi]					; add positive integer
		add		edi, 4						; point to next positive integer
		loop	addPositiveInt
		
		push	eax
		lea		ebx, msgTotalAmt
		push	ebx
		call	printf						; print total amount message
		add		esp, 8

	finish:
	}

    return 0;
}

