// Using Stack.cpp : Defines the entry point for the console application.
//

#include <iostream>
#include "string.h"

#define MAX_SZ 6

int main()
{
	char myArray[MAX_SZ] = "Hello";
	char newArray[MAX_SZ];
	memset(newArray, 0, sizeof(newArray));		// initialize myName char array to empty string

	_asm{
			mov		ecx, MAX_SZ-1
			mov		esi, 0

		pushIt:
			movzx	eax, myArray[esi]	; move each char to eax register
			push	eax					; push char onto stack
			inc		esi					; increment index counter
			loop	pushIt

			mov		ecx, MAX_SZ-1		; reset loop counter with MAX_SZ
			mov		esi, 0				; reset index counter

		popIt :
			pop		eax					; pop char out from stack in reverse
			mov		newArray[esi], al	; store char back into myArray
			inc		esi					; increment index counter
			loop	popIt

			lea		eax, newArray
			push	eax
			call	printf
			add		esp, 4
	}
	return 0;
}
